# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](http://keepachangelog.com/)
and this project adheres to [Semantic Versioning](http://semver.org/).

## [1.0] 2018-08-08

### Changed

- Moved PROD -> PRD

### Removed

- Removed `calo` from hostnames

### Added

- .vault_pass file for storing vault pass
- ignore .vault_pass from git
- Setup group_vars
- Added message queue hosts to inventory
- Added playbooks for aep endpoint and cf worker deployment
- Added gopass client for vault password management
- added ability to deploy db migrations
- checkout scripts use ssh rather than https
