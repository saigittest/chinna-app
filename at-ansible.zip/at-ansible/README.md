# AT Ansible

AT team ansible repo.

## Building a New Server

1. Provision DNS Record in Subnet Manager
1. Deploy using [Satellite](https://calo-satellite.cisco.com).
1. Run `ci/ansible/site.yml` to provision the roles to the host.

## License

See `LICENSE`

## Author Information

Ronald Valente <rovalent@cisco.com>
