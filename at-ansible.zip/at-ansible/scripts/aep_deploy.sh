#!/usr/bin/env bash

# This is the notes for hammer deployment of AT environemnt

# hammer organization list -> 1
# hammer location list -> 2 (ALLN01)
# hammer compute-resource list -> 3 (calo-alln01-vc)
# Datastore: "CS-AT-01"
# hammer hostgroup list -> 44 (DEV) 45 (PROD)
# hammer domain list -> 1 (cisco.com)
# hammer subnet list -> 33 | CALO-ALLN01-AT-SRVR
# hammer capsule list -> 1 | calo-satellite.cisco.com
# hammer partition-table list -> 190 | AEP-APP-KS OR 191 | AEP-DB-KS

function query_host () {

}

# Params: (server_name, ip, cpu, mem, disk_name, disk_size)
function create_host () {
  server_name=$1
  ip=$2

  domain_id='1'
  cpu='2'
  mem='4096'
  disk_name='app'
  disk_size='100'
  partition_table_id='190'
  hostgroup_id='45'

  hammer host create \
  --name "${server_name}" \
  --hostgroup-id "${hostgroup_id}" \
  --partition-table-id "${partition_table_id}" \
  --compute-resource "${vcenter}" \
  --interface="managed=true, \
              primary=true, \
              provision=true, \
              ip=${ip}, \
              domain_id=1, \
              subnet_id=33, \
              compute_type=VirtualVmxnet3, \
              compute_network=VMW-AT" \
  --organization-id 1 \
  --compute-attributes "cpus=${cpu}, \
                        memory_mb=${mem}, \
                        cluster=CALO, \
                        path=CALO-AT, \
                        guest_id=rhel7_64Guest, \
                        start=1" \
  --volume "name=os, \
            datastore=CS-AT-01, \
            size_gb=60, \
            thin=true" \
  --volume "name=${disk_name}, \
            datastore=CS-AT-01, \
            size_gb=${disk_size}, \
            thin=true" \
  --location-id 2
}

# Stage Environment - ALLN01
create_host "aep-stg-db1" "10.123.235.132" "4" "8192" "db" "100" "191" "44"
create_host "aep-stg-mq1" "10.123.235.141" "2" "4096" "app" "100" "190" "44"
create_host "aep-stg-api" "10.123.235.144" "2" "4096" "app" "100" "190" "44"
create_host "aep-stg-wk1" "10.123.235.145" "2" "4096" "app" "100" "190" "44"
create_host "aep-stg-ftp" "10.123.235.142" "2" "4096" "app" "100" "190" "44"

# Production Environment - ALLN01
create_host "aep-prd-db1" "10.123.235.134" "4" "8192" "db" "100" "191" "45"
create_host "aep-prd-mq1" "10.123.235.151" "2" "4096" "app" "100" "190" "45"
create_host "aep-prd-api" "10.123.235.140" "2" "4096" "app" "100" "190" "45"

# Workers by Site

## RTP (4) - calo-rtp-infra-vc
create_host "aep-prd-rtp-ftp" "10.122.157.250" "2" "4096" "app" "100" "190" "45"
create_host "aep-prd-rtp-wk1" "10.122.157.230" "2" "4096" "app" "100" "190" "45"
create_host "aep-prd-rtp-wk2" "10.122.157.231" "2" "4096" "app" "100" "190" "45"

# BGL (5) - calo-bgl-infra-vc
create_host "aep-prd-bgl-ftp" "10.104.210.230" "2" "4096" "app" "100" "190" "45"
create_host "aep-prd-bgl-wk1" "10.104.210.200" "2" "4096" "app" "100" "190" "45"
create_host "aep-prd-bgl-wk2" "10.104.210.201" "2" "4096" "app" "100" "190" "45"

# BRU (7) - calo-bru-infra-vc
#create_host "aep-prd-bru-ftp" "" "2" "4096" "app" "100" "190" "45"
#create_host "aep-prd-bru-wk1" "" "2" "4096" "app" "100" "190" "45"
#create_host "aep-prd-bru-wk2" "" "2" "4096" "app" "100" "190" "45"

# MXC (4) - calo-mxc-infra-vc
create_host "aep-prd-mxc-ftp" "10.31.104.120" "2" "4096" "app" "100" "190" "45"
create_host "aep-prd-mxc-wk1" "10.31.104.110" "2" "4096" "app" "100" "190" "45"
create_host "aep-prd-mxc-wk2" "10.31.104.111" "2" "4096" "app" "100" "190" "45"

# SYD (9) - calo-syd-infra-vc
create_host "aep-prd-syd-ftp" "10.66.79.90" "2" "4096" "app" "100" "190" "45"
create_host "aep-prd-syd-wk1" "10.66.79.70" "2" "4096" "app" "100" "190" "45"
create_host "aep-prd-syd-wk2" "10.66.79.71" "2" "4096" "app" "100" "190" "45"

# RCDN (8) - calo-rcdn-infra-vc
create_host "aep-prd-rcdn-ftp" "10.88.5.60" "2" "4096" "app" "100" "190" "45"
create_host "aep-prd-rcdn-wk1" "10.88.5.54" "2" "4096" "app" "100" "190" "45"
create_host "aep-prd-rcdn-wk2" "10.88.5.55" "2" "4096" "app" "100" "190" "45"

# TKY (12) - calo-tky-infra-vc
#create_host "aep-prd-tky-ftp" "" "2" "4096" "app" "100" "190" "45"
#create_host "aep-prd-tky-wk1" "" "2" "4096" "app" "100" "190" "45"
#create_host "aep-prd-tky-wk2" "" "2" "4096" "app" "100" "190" "45"
