#!/usr/bin/env bash

code_root="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )/../../"
role_root="${code_root}/ansible-roles"
github_host="calo-github.cisco.com"
github_org="cloud"
user=`whoami`


cat ${code_root}/at-ansible/requirements.yml|sed '1 d'|awk '{print $2}' |while read ROLE
do
if [ ! -d "${role_root}/${ROLE}" ]; then
    cd $role_root
    hub clone git@${github_host}:${github_org}/ansible-${ROLE}.git $ROLE
    cd $ROLE
    hub fork
    hub remote add upstream git@${github_host}:${github_org}/ansible-${ROLE}.git
    hub remote set-url origin git@${github_host}:${user}/ansible-${ROLE}.git
    hub remote rm $user
else
    echo "${ROLE} role already exists"
fi
done
