#!/usr/bin/env bash

## Shell Opts ----------------------------------------------------------------

# Exit on any unset variable
set -o nounset

# Pipeline's return status is the value of the last (rightmost) command
# to exit with a non-zero status, or zero if all commands exit successfully.
set -o pipefail

# Enable tracing
set -o xtrace

# Check if ansible is installed
command -v ansible-playbook >/dev/null 2>&1 || { echo >&2 "ansible is not installed.  Aborting."; exit 1; }

## Variables -----------------------------------------------------------------

export ANSIBLE_HOST_KEY_CHECKING=False
export ANSIBLE_ROLES_PATH=$(pwd)/..

## Main ----------------------------------------------------------------------

cd tests
[ -f requirements.yml ] && ansible-galaxy install -r requirements.yml -p roles || echo "tests/requirements.yml does not exist, continuing..."

# Ansible syntax Check
ansible-playbook -i inventory test.yml --syntax-check || { echo >&2 "test playbook syntax failed check.  Aborting."; exit 1; }
