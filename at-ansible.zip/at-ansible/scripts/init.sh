#!/usr/bin/env bash

## Shell Opts ----------------------------------------------------------------
set -o errexit          # Exit on any non-zero exit code
set -o nounset          # Exit on any unset variable
set -o pipefail         # Return status of last command
set -o xtrace           # Enable tracing

script_dir="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )/"
code_root="${script_dir}../../"
role_root="${code_root}/ansible-roles"

#set working dir
cd ${script_dir}


#make role root
mkdir -p ${role_root}

# ensure pipenv is installed
if ! [ -x "$(command -v pipenv)" ]; then
    if ! [ -x "$(command -v pip)" ]; then
        echo 'Error: pip is not installed. You have a bootstrapping problem' >&2
        echo 'Resolve this problem and try again' >&2
        exit 1
    fi
    sudo pip install pipenv
fi

# move up to code root
cd ../

#install project dependencies
pipenv install --dev

#make sure hub is installed
if ! [ -x "$(command -v hub)" ]; then
    if ! [ -x "$(command -v brew)" ]; then
        echo 'Error: brew is not installed. Either not on OSX or not installed' >&2
        echo 'either install hub or brew manually and rerun this script' >&2
        exit 1
    fi
fi

#setup hub
git config --global --add hub.host calo-github.cisco.com

echo "Please add the following to your .bash_profile or equivalent     GITHUB_HOST=calo-github.cisco.com" >&2
