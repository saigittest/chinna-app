#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# https://gist.github.com/wakemaster39/ceb79d1aebb1302c465d08803b77a383

import sys
import argparse
import subprocess
import os
import configparser
import random
import string

def build_arg_parser():
    parser = argparse.ArgumentParser(description='Get a vault password from user keyring')

    parser.add_argument('--vault-id', action='store', default=None,
                        dest='vault_id',
                        help='name of the vault secret to get from keyring')
    return parser

def main():
    curdir = os.path.dirname(__file__)
    config = configparser.ConfigParser()
    config.read(os.path.join(curdir, "../ansible.cfg"))

    mount = config['gopass-client']['mount']
    if mount is None:
      sys.exit(1)
    directory = config['gopass-client']['directory']
    if directory is None:
      sys.exit(1)
    suppress_gopass_errors = config['gopass-client'].getboolean('suppress_gopass_errors')

    arg_parser = build_arg_parser()
    args = arg_parser.parse_args()

    keyname = args.vault_id

    result = subprocess.run(["gopass", "show", f"%s/%s/%s" % (mount, directory, keyname)], stdout=subprocess.PIPE, stderr=subprocess.PIPE)

    if result.returncode != 0 and not suppress_gopass_errors:
      sys.stderr.write(result.stderr.decode("utf-8"))
      sys.exit(result.returncode)
    elif suppress_gopass_errors:
      sys.stdout.write(''.join(random.SystemRandom().choice(string.ascii_uppercase + string.digits) for _ in range(20))+'\n')
    else:
      sys.stdout.write('%s\n' % result.stdout.decode("utf-8"))

    sys.exit(0)


if __name__ == '__main__':
    main()
