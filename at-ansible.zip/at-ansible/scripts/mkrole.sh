#!/usr/bin/env bash

## Shell Opts ----------------------------------------------------------------
set -o errexit          # Exit on any non-zero exit code
set -o nounset          # Exit on any unset variable
set -o pipefail         # Return status of last command
set -o xtrace           # Enable tracing

## Variables -----------------------------------------------------------------
role=$1
code_root="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )/../../"
role_skel="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )/skel"
role_root="${code_root}/ansible-roles"
github_org="cloud"

## Main ----------------------------------------------------------------------
# Check to see if we have 1 argument
if [ $# -eq 0 ]; then
    echo "USAGE: ./mkroles.sh ROLE_NAME"
fi

# Create Roles
if [ ! -d "${role_root}/${role}" ]; then
    # Build Role Skeleton from Ansible Galaxy
    # Run from scripts dir so we have this instance of ansible to generate from
    cd "$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )" || exit
    echo "==> Creating New Role Locally"
    pipenv run ansible-galaxy init "ansible-${role}" --init-path="${role_root}/"

    cd "${role_root}" || exit

    # Hop into the role and initialize it as a git repo
    echo "==> Initialize Git Repo for ansible-${role}"
    cd "${role_root}/ansible-${role}" || exit
    git init .

    #copy Pipfile
    cp "${role_skel}/Pipfile" .
    pipenv install --dev

    # Copy LICENSE File
    cp "${role_skel}/LICENSE" .

    # Don't commit with Empty Files/Templates Dirs
    mkdir -p templates
    mkdir -p files
    touch templates/.git_keep
    touch files/.git_keep

    # Create Meta File
    cp "${role_skel}/meta.yml" meta/main.yml
    sed -i '' "s/ROLE_NAME/$role/" meta/main.yml

    # Create CHANGELOG.md File
    cp "${role_skel}/CHANGELOG.md" CHANGELOG.md

    # Update additional files
    cp "${role_skel}/test.sh" test.sh
    cp "${role_skel}/Jenkinsfile" Jenkinsfile
    cp "${role_skel}/gitignore" .gitignore

    # Test Code
    cp "${role_skel}/inventory" tests/inventory
    cp "${role_skel}/test.yml" tests/test.yml
    sed -i '' "s/ROLE_NAME/$role/" tests/test.yml

    # Support Dependencies
    mkdir -p tests/roles
    touch tests/roles/.git_keep

    # Add/Commit
    echo "==> Add and commit all files into git for ansible-${role}"
    git add -A
    git commit -m 'initial role import'

    echo "==> Create repo on calo-github"
    GITHUB_HOST=calo-github.cisco.com  hub create -p "${github_org}/ansible-${role}"
    git push origin master

    echo "==> Fork Role"
    hub fork "${github_org}/ansible-${role}"
    cd "${role_root}" || exit

    echo "==> Remove Role"
    rm -rf "ansible-${role}"

    echo "==> Clone Fork"
    hub clone "ansible-${role}" "${role}"
    cd "${role}" || exit

    echo "==> Add Upstream ${github_org}"
    hub remote add upstream ${github_org}
fi
