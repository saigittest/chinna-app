#!/usr/bin/env bash

## Shell Opts ----------------------------------------------------------------
set -o errexit          # Exit on any non-zero exit code
set -o nounset          # Exit on any unset variable
set -o pipefail         # Return status of last command
set -o xtrace           # Enable tracing

## Variables -----------------------------------------------------------------
code_root="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )/../../"
role_root="${code_root}/ansible-roles"
role_skel="${code_root}/at-ansible/scripts/skel"
roles=$(ls "${role_root}")

## Main ----------------------------------------------------------------------
for role in ${roles}
do
    echo "=== ${role} ==="
    cd "${role_root}/${role}"
    cp "${role_skel}/test.sh" test.sh
    cp "${role_skel}/Jenkinsfile" Jenkinsfile
done
