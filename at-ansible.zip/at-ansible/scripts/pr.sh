#!/usr/bin/env bash

## Shell Opts ----------------------------------------------------------------
#set -o errexit          # Exit on any non-zero exit code
set -o nounset          # Exit on any unset variable
set -o pipefail         # Return status of last command
#set -o xtrace           # Enable tracing

## Variables -----------------------------------------------------------------
code_root="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )/../../"
role_root="${code_root}/ansible-roles"
roles=$(ls "${role_root}")

# Check to see if we have 1 argument
if [ $# -eq 0 ]; then
    echo "USAGE: ./pr.sh 'Commit Message'"
fi

commit_msg=$1

## Main ----------------------------------------------------------------------
for role in ${roles}
do
    echo "=== ${role} ==="
    cd "${role_root}/${role}"
    git add .
    git commit -m "$commit_msg"
    git pull
    git pull upstream master
    git push
    changes=$(git diff upstream/master | wc -l)
    if [ $changes -gt 0 ]; then
        hub pull-request "$commit_msg"
    fi
    echo ""
done
